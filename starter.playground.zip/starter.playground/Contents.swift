import Foundation
import SwiftUI
import PlaygroundSupport
import Dispatch

//let serialQueue = DispatchQueue(label: "ncx.project",attributes: .concurrent)
//
//
//serialQueue.async {
//    print("Task 1 started")
//    print("Task 1 finish")
//}
//
//serialQueue.async {
//    print("Task 2 started")
//    print("Task 2 finish")
//}




class demoClass: ObservableObject {
    @Published var vstackColor: Color = .red
    
    let array: [TimeInterval] = [
        1,
        5
    ]
    
    
    func getData () {
        let group = DispatchGroup()
        
        for number in array {
            
            group.enter()
            
            print("Entering group number: \(number)")
            
            DispatchQueue.global().asyncAfter(deadline: .now() + number, execute: {
                group.leave()
                print("Leaving group number: \(number)")
            })
        }
        
        group.notify(queue: .main, execute: {
            print("Done all operations")
            self.vstackColor = .green
        })

    }
    
}

/*
 LANDING SCENE
 */
struct LandingView: View {
    
    @StateObject var colorClass = demoClass()
    
    var body: some View {
        VStack {
            Text("Demo DispatchGroup")
            Button(action: colorClass.getData) {
                Text("Start Tasks")
            }
        }
        .frame(width: 300, height: 300, alignment: .center)
        .background(colorClass.vstackColor)
    }
}

PlaygroundPage.current.setLiveView(LandingView())
